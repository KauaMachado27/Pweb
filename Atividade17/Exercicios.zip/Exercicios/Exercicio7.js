let http = require('http');

let server = http.createServer(function (req, res) {

    let opcao = req.url;

    if (opcao == '/historia') {
        res.end("<html><body>História da Fatec Sorocaba</body></html>");
    }
    else if (opcao == '/cursos') {
        res.end("<html><body>Cursos</body></html>");
    }
    else if (opcao == '/professores') {
        res.end("<html><body>Professores</body></html>");
    }
    else {
        res.end("<html><body>Página não encontrada</body></html>");
    }

});

server.listen(3000);
console.log('servidor iniciado na porta 3000');