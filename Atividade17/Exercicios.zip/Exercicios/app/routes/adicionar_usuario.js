module.exports = function(app){
    app.get('/admin/adicionar_usuario',function(req,es){res.render("admin/adicionar_usuario");
  
});
}